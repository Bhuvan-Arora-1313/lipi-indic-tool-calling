Indic Tool-Calling Robustness -- Midterm Report (Overleaf project)

HOW TO USE ON OVERLEAF
1. New Project -> Upload Project -> select this .zip.
2. Menu (top-left) -> Compiler -> XeLaTeX   <-- required for the Hindi example in Figure 1.
   (pdfLaTeX also compiles, but shows the Hindi words in romanized form instead of Devanagari.)
3. Main document: main.tex. Click Recompile.

FILES
main.tex               the paper (ACL format, "preprint" option = author names shown)
references.bib         bibliography
acl.sty, acl_natbib.bst  official ACL style files
figures/*.tex          all figures, drawn in TikZ / pgfplots (no image files)
fonts/                 Noto Sans Devanagari + Tamil (SIL Open Font License, see fonts/OFL.txt)

To switch to anonymous review format, change \usepackage[preprint]{acl} to \usepackage[review]{acl}.
All numbers come from the project's score files (result/, score/) and review data (data/reviews/).
