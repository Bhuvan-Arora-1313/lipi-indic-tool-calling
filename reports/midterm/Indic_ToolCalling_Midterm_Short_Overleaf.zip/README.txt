LIPI: Right Tool, Wrong Script in Indic-Language LLM Tool Calling -- Midterm short paper (Overleaf project)

HOW TO USE ON OVERLEAF
1. New Project -> Upload Project -> select this .zip.
2. Menu (top-left) -> Compiler -> XeLaTeX   <-- required for the Hindi example in Figure 1.
3. Main document: main.tex. Click Recompile.

LAYOUT
Main body (Abstract to Conclusion) = 4 pages. Limitations, Acknowledgements,
References and Appendices A-H follow and do not count toward the page limit.

PLACEHOLDERS
\tbd prints a grey "TBD" in tables and \pending{...} prints orange
"[Pending: ...]" text. Both are defined in the preamble. Search main.tex for
"\tbd" and "\pending" to find every result that still has to be filled in.

FILES
main.tex               the paper (ACL format, "preprint" option = author names shown)
references.bib         bibliography (checked 2026-10-13, published versions used where they exist)
acl.sty, acl_natbib.bst  official ACL style files
figures/*.tex          figures, drawn in TikZ / pgfplots (no image files)
fonts/                 Noto Sans Devanagari + Tamil (SIL Open Font License, see fonts/OFL.txt)

All numbers come from the project's score files (result/, score/) and review data (data/reviews/).
